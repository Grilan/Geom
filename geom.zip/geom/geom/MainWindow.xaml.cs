﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace geom
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
   
        Random rn = new Random();
        struct SP
        {

            public double k;
            public int x;
            public int y;
            public SP(double hk, int hx, int hy)
            {
                k = hk;
                x = hx;
                y = hy;

            }
        }

        List<SP> LST = new List<SP>();
        public void LSTZ()
        {
            for (int i = 0; i < 1; i++)
            {
                int k = rn.Next(5, 20);
                int x = rn.Next(0, (int)this.Width - (k * 20));
                int y = rn.Next(0, (int)this.Height - (k * 18));
                LST.Add(new SP(k, x, y));
            }
            ris();
        }
        string txt ="Васильева";
        int dx;
        int dy;
        double w;
        double h;
        double w1;
        double h1;
                        
        public MainWindow()
        {
            InitializeComponent();
            DispatcherTimer tm = new DispatcherTimer();
            tm.Interval = new TimeSpan(0, 0, 0, 0, 10);
            tm.Tick += tmtic2;
            tm.Start();
            dx = rn.Next(-5,5);
            dy = rn.Next(-5,5);
            w = 175 * k;
            h = 180 * k;
            w1 = 175 * k;
            h1 = 180 * k;
            ris();

        }
        void tmtic2(object sender, EventArgs e)
        {

            x3 += dx;
            y3 += dy;
            ris();
            if (x3 < 0 || x3 > Width - 180)
            {
                dx *= -1;
            }

            if (y3 < 0 || y3 > Height - 175)
            {
                dy *= -1;
                

            }

            if (((y2 < y3 + h1) && (y2 > y3 + h1 - 10) && (x2 > x3 - w) && (x2 < x3 + w1)) 
               || ((y2 > y3 - h) && (y2 < y3 - h + 10) && (x2 > x3 - w) && (y2 < y3 + w1)))
            {
                dy *= -1;

            }
            if (((x2 < x3 + w1) && (x2 > x3 + w1 - 10) && (y2 > y3 - h) && (y2 < y3 + h1)) 
               || ((x2 > x3 - w) && (x2 < x3 - w + 10) && (y2 > y3 - h) && (y2 < y3 + h1)))
            {
                dx *= -1;
            }
           
        }

        public void ris()
        {
            Rect polotno = new Rect(0, 0, this.Width, this.Height);
            DrawingVisual visual_img = new DrawingVisual();
            using (DrawingContext context_img = visual_img.RenderOpen())
            {
                img.Source = new BitmapImage(new Uri("/Resources/31.jpg", UriKind.RelativeOrAbsolute));
                context_img.DrawImage(img.Source, polotno);

               
                 for(int i = 0; i < LST.Count; i++)
                 {
                   Draw(LST[i].k / 10, LST[i].x, LST[i].y, context_img);
                 }

                Draw(k, x2, y2, context_img);
                Draw(k, x3, y3, context_img);


            }
            RenderTargetBitmap render_img = new RenderTargetBitmap((int)polotno.Width, (int)polotno.Height, 96, 96, PixelFormats.Default);
            render_img.Render(visual_img);
            img.Source = render_img;
        }
        double k = 1;
        int x2 = 300;
        int y2 = 300;
        int x3;
        int y3;

        public void Draw(double k, int x, int y, DrawingContext context_img)
        {
            context_img.DrawRectangle(Brushes.Black, null, new Rect(x + 75/k, y + 0/k, 50/k, 10/k));
            context_img.DrawRectangle(Brushes.Black, null, new Rect(x + 55/k, y + 10/k, 20 / k, 10 / k));
            context_img.DrawRectangle(Brushes.Black, null, new Rect(x + 45/k, y + 20/k, 10 / k, 20 / k));
            context_img.DrawRectangle(Brushes.Black, null, new Rect(x + 35/k, y + 40/k, 10 / k, 50 / k));
            context_img.DrawRectangle(Brushes.Black, null, new Rect(x + 125/k, y + 10/k, 20 / k, 10 / k));
            context_img.DrawRectangle(Brushes.Black, null, new Rect(x + 145 / k, y + 20 / k, 10 / k, 20 / k));
            context_img.DrawRectangle(Brushes.Black, null, new Rect(x + 155 / k, y + 40/k, 10 / k, 50 / k));
            context_img.DrawRectangle(Brushes.Black, null, new Rect(x + 25 / k, y + 90/k, 10 / k, 20 / k));
            context_img.DrawRectangle(Brushes.Black, null, new Rect(x + 35 / k, y + 110/k, 10 / k, 10 / k));
            context_img.DrawRectangle(Brushes.Black, null, new Rect(x + 165 / k, y + 90 / k, 10 / k, 20 / k));
            context_img.DrawRectangle(Brushes.Black, null, new Rect(x + 155 / k, y + 110 / k, 10 / k, 10 / k));
            context_img.DrawEllipse(Brushes.Black, null, new Point(x + 100/k, y + 110 / k), 55/k, 60/k);
            context_img.DrawEllipse(Brushes.Red, new Pen(Brushes.White,10/k), new Point(x + 80 / k, y + 100 / k), 10 / k, 10 / k);
            context_img.DrawEllipse(Brushes.Red, new Pen(Brushes.White, 10/k), new Point(x + 120 / k, y + 100 / k), 10 / k, 10 / k);
            context_img.DrawRectangle(Brushes.Gold, null, new Rect(x + 85 / k, y + 125 / k, 30 / k, 10 / k));
            context_img.DrawRectangle(Brushes.Orange, null, new Rect(x + 35 / k, y + 90 / k, 10 / k, 20 / k));
            context_img.DrawRectangle(Brushes.Orange, null, new Rect(x + 155 / k, y + 90 / k, 10 / k, 20 / k));
            context_img.DrawText(new FormattedText(txt, CultureInfo.CurrentCulture, FlowDirection.LeftToRight, new Typeface("Showcard Gothic"), 32 / k, Brushes.Black), new Point(x + 20 / k, y + 180 / k));
            
        }
               
        private void Img_MouseDown(object sender, MouseButtonEventArgs e)
        {
            LST.Clear();
            LSTZ();
        }

        private void Window_KeyDown(object sender, KeyEventArgs e)
        {
            ris();
            if (e.Key == Key.Left) { x2 -= 10; }
            if (e.Key == Key.Right) { x2 += 10; }
            if (e.Key == Key.Up) { y2 -= 10; }
            if (e.Key == Key.Down) { y2 += 10; }
         
        }
    }
    
}
